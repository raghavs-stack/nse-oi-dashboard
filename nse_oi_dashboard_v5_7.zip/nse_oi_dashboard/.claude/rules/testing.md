# Testing Rules — NSE OI Dashboard

## Required Tests Before Any Commit

### 1. Syntax Check (always)
```bash
python3 -c "
import ast, os
errors = []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', '.claude')]
    for f in files:
        if f.endswith('.py'):
            path = os.path.join(root, f)
            try:
                ast.parse(open(path).read())
                print(f'OK  {path}')
            except SyntaxError as e:
                errors.append(f'ERR {path}: {e}')
                print(f'ERR {path}: {e}')
print()
print('ALL OK' if not errors else f'ERRORS: {len(errors)} files')
"
```

### 2. Import Check
```bash
python3 -c "
import config, state
from core.market_hours import now_ist, is_market_open
from signals.oi_analytics import calc_max_pain, calc_localized_pcr
from signals.advanced_analytics import run_advanced_analytics
from alerts.telegram_alerts import init_telegram
print('All imports OK')
"
```

### 3. Analytics Unit Test (use sample data)
```bash
python3 -c "
import pandas as pd
from signals.advanced_analytics import run_advanced_analytics

# Minimal test DataFrame
df = pd.DataFrame({
    'Strike': [24000, 24100, 24200, 24300, 24400],
    'CE_OI':  [50, 80, 120, 90, 60],
    'PE_OI':  [40, 70, 100, 60, 30],
    'CE_Chg': [5, 10, 15, 8, 4],
    'PE_Chg': [3, 7, 12, 5, 2],
    'CE_Vol': [1000, 2000, 3000, 1500, 800],
    'PE_Vol': [800, 1800, 2500, 1200, 600],
    'CE_IV':  [12, 11, 11.4, 12, 13],
    'PE_IV':  [15, 14, 13.8, 14.5, 16],
    'CE_LTP': [200, 150, 98, 60, 30],
    'PE_LTP': [30, 50, 80, 120, 180],
})
spot = 24187.65
result = run_advanced_analytics(df, spot)
assert 'gamma' in result
assert 'smart_money' in result
assert 'breakout' in result
print('advanced_analytics: PASS')
print('GEX regime:', result['gamma']['regime'])
print('Dealer bias:', result['dealer']['bias'])
"
```

### 4. Demo Mode Test
```bash
# Should run without credentials (uses sample data)
timeout 10 python3 main.py --demo 2>&1 | head -20
```

## Testing Rules
- Never test live API calls without market hours check
- Never commit failing tests
- All new analytics functions must have a standalone test in the docstring (as example)
- If `is_market_open()` is False, data fetch tests must be skipped gracefully
- Sample data in `samples/` directory is the canonical test fixture

## What NOT to Test
- Shoonya login (requires live credentials + TOTP)
- Live option chain fetch (market hours + credentials)
- Telegram send (requires bot token)

These are tested manually with `--demo` mode and visual inspection.
