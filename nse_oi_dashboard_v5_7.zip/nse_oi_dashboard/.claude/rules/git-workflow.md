# Git Workflow — NSE OI Dashboard

## Commit Message Format
```
type(scope): short description

Types: feat | fix | refactor | docs | test | chore
Scope: analytics | data | display | signal | alerts | config

Examples:
feat(analytics): add OI momentum build rate per strike
fix(data): handle missing CE_IV column from Shoonya
refactor(signal): extract dealer vote as 5th scoring factor
docs(readme): add Shoonya TOTP setup instructions
```

## Pre-Commit Mandatory Checks
```bash
# 1. credentials not staged (CRITICAL)
git diff --cached --name-only | grep credentials.py
# Must return nothing

# 2. syntax clean
python3 -m py_compile main.py config.py state.py

# 3. imports work
python3 -c "import main" 2>&1 | grep -v "credentials"

# 4. .gitignore has credentials.py
grep "credentials.py" .gitignore
```

## What to NEVER Commit
- `credentials.py`
- `*.csv` signal logs (daily output files)
- `dashboard_state.json`
- `__pycache__/`
- `*.pyc`
- `nse_oi_chart.png` (generated plot)
- `logs/` directory

## Branch Strategy
```
main        — stable, tested version
dev         — active development
fix/xyz     — hotfix branches
feat/xyz    — feature branches
```

## .gitignore (ensure these are present)
```
credentials.py
*.csv
dashboard_state.json
__pycache__/
*.pyc
*.png
logs/
.env
```
