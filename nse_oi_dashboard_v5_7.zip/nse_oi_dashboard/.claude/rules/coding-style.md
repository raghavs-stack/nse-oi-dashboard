# Coding Style — NSE OI Dashboard

## Python Style

### Imports (order strictly enforced)
```python
# 1. stdlib
import os, time, json
from datetime import datetime

# 2. third-party
import pandas as pd
import pyotp

# 3. local — always use explicit relative imports
import state
from config import SYMBOL, LOT_SIZE
from core.market_hours import now_ist
```

### Type Hints (required on all public functions)
```python
def calc_gamma_exposure(df: pd.DataFrame, spot: float) -> dict:
```

### Docstrings (required on all public functions)
```python
def calc_smart_money(df: pd.DataFrame) -> dict:
    """
    Smart Money Score = OI_Change × Volume × (1 / (IV + 1))
    Returns top 3 call and put strikes with institutional positioning.
    Low IV + high OI build + high volume = smart money entry.
    """
```

### Constants — all in config.py
```python
# WRONG — magic number in code
atm = round(spot / 50) * 50

# RIGHT — use config or derive from symbol
from core.nse_fetcher import strike_step
atm = round(spot / strike_step(symbol)) * strike_step(symbol)
```

### State Mutation
```python
# WRONG — module-level mutable state
_cache = {}  # never do this outside state.py

# RIGHT — use state module
import state
state.prev_oi = new_oi_dict
```

### DataFrame Operations
```python
# WRONG — iterate rows
for idx, row in df.iterrows():
    result.append(row["CE_OI"] * row["CE_Chg"])

# RIGHT — vectorise
df["score"] = df["CE_OI"] * df["CE_Chg"]
```

### Error Handling
```python
# Every API call needs try/except
try:
    data = api.get_option_chain(...)
except Exception as e:
    print(f"  fetch error: {type(e).__name__}: {e}")
    return {}  # always return safe default, never propagate to main loop
```

## File Size Limits
- No single file > 500 lines
- If `oi_analytics.py` or `iv_analytics.py` grows > 400 lines, split into sub-modules

## Naming Conventions
- Functions: `snake_case`, verb-noun: `calc_max_pain()`, `fetch_option_chain()`
- Constants: `UPPER_SNAKE_CASE` in `config.py`
- DataFrame columns: `PascalCase_CAPS` e.g. `CE_OI`, `PE_Chg`
- Files: `snake_case.py`
