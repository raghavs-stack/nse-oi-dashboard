# Security Rules — NSE OI Dashboard

## Mandatory — Never Violate

### Credential Management
- ALL secrets live in `credentials.py` only — never in any other file
- `credentials.py` is in `.gitignore` — verify before every commit: `cat .gitignore | grep credentials`
- Never log, print, or include secrets in error messages
- Never pass credentials as function arguments — import from `credentials` module directly in the module that needs them
- If credentials.py is accidentally committed: rotate ALL credentials immediately (Shoonya password + Telegram token)

### Broker Security
- This dashboard is READ-ONLY — zero order placement code is ever permitted
- Shoonya session token must not appear in any log or stdout output
- TOTP key (permanent seed) must never be printed even during debugging
- SHA-256 hash the password before sending — already done in `shoonya_client.py`, never bypass

### No Hardcoded Sensitive Values
```python
# WRONG
api_secret = "abc123xyz"

# RIGHT
from credentials import SHOONYA_API_SECRET
```

### Telegram Safety
- Bot token and chat_id in `credentials.py` only
- Never send account balance, PnL, or position details via Telegram
- Signal messages show strike/premium/bias only — no personal trading details

## Pre-Commit Checklist
Run before every `git commit`:
```bash
# 1. credentials not staged
git status | grep credentials.py  # must show nothing

# 2. no hardcoded secrets
grep -rn "password\s*=\s*['\"]" . --include="*.py" --exclude="credentials*"

# 3. syntax clean
python3 -m py_compile main.py config.py state.py
```
