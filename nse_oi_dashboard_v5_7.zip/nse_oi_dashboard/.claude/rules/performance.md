# Performance Rules — NSE OI Dashboard

## Cycle Budget (35 seconds per cycle)
```
API fetch:          ~3-8s   (Shoonya option chain)
Analytics compute:  <0.5s   (all signals combined)
Display render:     <0.2s   (terminal or Tkinter)
State write:        <0.1s   (dashboard_state.json)
Sleep:              remainder to fill 35s
```
**Never let analytics computation exceed 2 seconds.**

## Model Selection (for Claude Code usage)
| Task | Model |
|------|-------|
| Agents (analytics, data, signal) | `claude-sonnet-4-5` (fast + capable) |
| Security review | `claude-sonnet-4-5` |
| Simple edits, config changes | `claude-haiku-4-5` |

## Python Performance Rules

### Pandas — vectorise everything
```python
# SLOW (1000× worse for large DataFrames)
for _, row in df.iterrows():
    scores.append(row["CE_OI"] * row["CE_Chg"])

# FAST
scores = (df["CE_OI"] * df["CE_Chg"]).tolist()
```

### Shoonya API — batch where possible
```python
# The option chain fetch already batches strikes
# Don't add extra get_quotes() calls per cycle
# Cache VIX: only fetch every 5 cycles if unchanged
```

### Memory — rolling window for IV history
```python
# IVHistory keeps max 252 entries (one year of daily IV)
# Never unbounded accumulation in signal_log
MAX_SIGNAL_LOG = 500  # in config.py — prune if exceeded
```

### Matplotlib — non-blocking
```python
# Always close figure after saving
plt.tight_layout()
plt.savefig(PLOT_FILE, dpi=110, bbox_inches="tight")
plt.close(fig)  # CRITICAL — memory leak if missing
```

### State JSON write — atomic
```python
# Write to temp file, rename (atomic on all platforms)
import tempfile
with tempfile.NamedTemporaryFile('w', delete=False, suffix='.json') as tmp:
    json.dump(state_data, tmp)
os.replace(tmp.name, "dashboard_state.json")
```

## Context Management (Claude Code)
- Keep agent prompts focused — one agent per domain
- Don't enable unused MCP servers — each adds context overhead
- Run `/compact` when context window > 70% full
- Use `--demo` for testing to avoid wasting API calls on live data
