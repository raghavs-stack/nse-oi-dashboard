# /add-analytics — Add New Analytics Module

Scaffolds a new analytics function following the project pattern.

## Usage
```
/add-analytics <name> <description>

Examples:
/add-analytics vwap-divergence "Detect divergence between spot and VWAP as trade signal"
/add-analytics call-wall-tracker "Track CE OI wall migration across cycles"
/add-analytics expiry-decay "Model premium decay acceleration near expiry"
```

## What Claude will do

1. Create the function in `signals/advanced_analytics.py` following this template:

```python
# ── <Name> ─────────────────────────────────────────────────────────────
def calc_<name>(df: pd.DataFrame, spot: float) -> dict:
    """
    <One-line trading logic explanation>
    
    <How to interpret the output for trading decisions>
    
    Returns dict with keys:
        <key>: <description>
    """
    if df.empty:
        return {"<key>": None, "signal": "N/A"}
    
    # ... implementation ...
    
    return {
        "<key>": value,
        "signal": "BULLISH" | "BEARISH" | "NEUTRAL",
    }
```

2. Add it to `run_advanced_analytics()` composite function

3. Wire it into `main.py` → `adv` dict

4. Add display in `display/terminal.py` advanced analytics section

5. Add to `streamlit_app.py` advanced metrics row

6. Run `/check` to validate

## Rules for new analytics
- Must return a dict with at minimum a "signal" key: BULLISH | BEARISH | NEUTRAL
- Must handle empty DataFrame gracefully
- Must not import from `display/` or `alerts/` — analytics is pure computation
- Must be vectorised (no iterrows())
- Document the trading intuition in the docstring, not just the math
