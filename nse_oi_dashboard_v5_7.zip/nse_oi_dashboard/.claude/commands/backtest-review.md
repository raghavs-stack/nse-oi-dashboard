# /backtest-review — Review Today's Signal Performance

Analyses the daily CSV log to review signal quality and P&L.

## What it does

Reads the daily CSV log (`NIFTY_OI_YYYYMMDD.csv`) and computes:
- Win rate of taken signals
- Average score of winning vs losing signals
- Best and worst performing times of day
- PCR level vs outcome correlation

```bash
python3 -c "
import pandas as pd
import glob
from datetime import datetime

# Find today's log
today = datetime.now().strftime('%Y%m%d')
files = glob.glob(f'*OI*{today}*.csv') + glob.glob('NIFTY_OI_*.csv')
if not files:
    print('No log file found. Run main.py first to generate signals.')
    exit()

df = pd.read_csv(sorted(files)[-1])
print(f'Log: {sorted(files)[-1]}')
print(f'Total cycles: {len(df)}')
print()

if 'Taken' in df.columns:
    taken = df[df['Taken']==True]
    print(f'Signals taken: {len(taken)}')
    if len(taken) > 0 and 'Score' in df.columns:
        print(f'Avg score (taken): {taken[\"Score\"].mean():.1f}')
        print(f'Avg score (skipped): {df[df[\"Taken\"]==False][\"Score\"].mean():.1f}')

if 'Bias' in df.columns:
    print()
    print('Bias distribution:')
    print(df['Bias'].value_counts().to_string())

if 'PCR_Local' in df.columns:
    print()
    print(f'PCR range: {df[\"PCR_Local\"].min():.3f} → {df[\"PCR_Local\"].max():.3f}')
    print(f'PCR mean: {df[\"PCR_Local\"].mean():.3f}')

if 'Score' in df.columns:
    print()
    print('Score distribution:')
    bins = [0,40,55,70,85,100]
    labels = ['<40 (weak)','40-55 (below min)','55-70 (ok)','70-85 (good)','85+ (strong)']
    df['score_bucket'] = pd.cut(df['Score'], bins=bins, labels=labels)
    print(df['score_bucket'].value_counts().sort_index().to_string())
"
```

## Instructions for Claude
1. Run the analysis above
2. Identify patterns: what time of day had the best signals?
3. Suggest 1-2 config adjustments based on today's data
4. Never recommend more than 2 config changes at once
5. Always validate with `/check` after any changes
