# /check — Full Health Check

Runs all validation checks on the NSE OI Dashboard codebase.

## What it does

1. **Syntax check** all 23 Python files
2. **Import check** all major modules
3. **Analytics unit test** with sample data
4. **Security scan** for hardcoded secrets
5. **Config validation** — required constants present

## Run

```bash
echo "=== SYNTAX CHECK ===" && python3 -c "
import ast, os
errors = []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', '.claude')]
    for f in files:
        if f.endswith('.py'):
            p = os.path.join(root, f)
            try: ast.parse(open(p).read()); print(f'  OK  {p}')
            except SyntaxError as e: errors.append(p); print(f'  ERR {p}: {e}')
print(f'\nResult: {\"ALL OK\" if not errors else str(len(errors)) + \" ERRORS\"}\n')
" && \
echo "=== IMPORT CHECK ===" && python3 -c "
try:
    import config, state
    from core.market_hours import now_ist, is_market_open
    from core.nse_fetcher import nearest_strike, strike_step
    from signals.oi_analytics import calc_max_pain, calc_localized_pcr, score_signal
    from signals.iv_analytics import IVTracker, IVHistory
    from signals.advanced_analytics import run_advanced_analytics
    from backtest.eod_backtest import Signal, TradeRec
    from alerts.telegram_alerts import init_telegram
    print('  All imports: OK')
except ImportError as e:
    print(f'  IMPORT ERROR: {e}')
" && \
echo "=== ANALYTICS TEST ===" && python3 -c "
import pandas as pd
from signals.advanced_analytics import run_advanced_analytics
from signals.oi_analytics import calc_max_pain, calc_localized_pcr

df = pd.DataFrame({
    'Strike': [24000.0, 24100.0, 24200.0, 24300.0, 24400.0],
    'CE_OI':  [50, 80, 120, 90, 60], 'PE_OI': [40, 70, 100, 60, 30],
    'CE_Chg': [5, 10, 15, 8, 4],    'PE_Chg': [3, 7, 12, 5, 2],
    'CE_Vol': [1000,2000,3000,1500,800], 'PE_Vol': [800,1800,2500,1200,600],
    'CE_IV':  [12,11,11.4,12,13],    'PE_IV': [15,14,13.8,14.5,16],
    'CE_LTP': [200,150,98,60,30],    'PE_LTP': [30,50,80,120,180],
})
spot = 24187.65
adv = run_advanced_analytics(df, spot)
mp  = calc_max_pain(df)
pcr = calc_localized_pcr(df, spot)
assert 'gamma' in adv and 'dealer' in adv and 'breakout' in adv
print(f'  GEX: {adv[\"gamma\"][\"regime\"]}')
print(f'  Dealer: {adv[\"dealer\"][\"bias\"]}')
print(f'  Max Pain: {mp}')
print(f'  Local PCR: {pcr}')
print('  Analytics test: PASS')
" && \
echo "=== SECURITY SCAN ===" && \
grep -rn "password\s*=\s*['\"][^'\"]\|api_secret\s*=\s*['\"]" . \
  --include="*.py" --exclude="credentials*" --exclude-dir=".claude" \
  --exclude-dir="__pycache__" 2>/dev/null \
  | grep -v "SHOONYA_PASSWORD\s*=\s*\"YOUR\|hashlib\|sha256" \
  && echo "  WARNING: Potential hardcoded secrets above" \
  || echo "  No hardcoded secrets found: OK" && \
echo "=== DONE ==="
```

After running, show a summary table:
| Check | Status |
|-------|--------|
| Syntax | ✅/❌ |
| Imports | ✅/❌ |
| Analytics | ✅/❌ |
| Security | ✅/❌ |
