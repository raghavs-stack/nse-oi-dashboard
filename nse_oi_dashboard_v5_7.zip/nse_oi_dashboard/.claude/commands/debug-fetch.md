# /debug-fetch — Diagnose Shoonya Data Fetch Issues

Systematically debugs why option chain data is empty or malformed.

## Diagnosis Steps

Run in order. Stop at the first failure.

```bash
echo "=== STEP 1: Market Hours ===" && python3 -c "
from core.market_hours import is_market_open, now_ist, next_open_str
import pytz
ist = pytz.timezone('Asia/Kolkata')
from datetime import datetime
now = datetime.now(ist)
print(f'  Current IST: {now.strftime(\"%H:%M:%S %a %d %b %Y\")}')
open_ = is_market_open()
print(f'  Market Open: {open_}')
if not open_:
    print(f'  Next open: {next_open_str()}')
    print('  DIAGNOSIS: Data empty because market is closed. Use --demo mode.')
else:
    print('  Market is OPEN — proceed to next step')
"

echo "=== STEP 2: Credentials File ===" && python3 -c "
import os
if not os.path.exists('credentials.py'):
    print('  MISSING: credentials.py not found')
    print('  FIX: cp credentials_template.py credentials.py && edit credentials.py')
else:
    import credentials as c
    fields = ['SHOONYA_USER_ID','SHOONYA_PASSWORD','SHOONYA_TOTP_KEY',
              'SHOONYA_VENDOR_CODE','SHOONYA_API_SECRET','SHOONYA_IMEI']
    missing = [f for f in fields if not getattr(c, f, None) or 'YOUR' in str(getattr(c, f, ''))]
    if missing:
        print(f'  INCOMPLETE: {missing}')
    else:
        print('  credentials.py: All fields present OK')
"

echo "=== STEP 3: Package Check ===" && python3 -c "
packages = ['NorenRestApiPy','pyotp','pandas','pytz','yfinance']
for p in packages:
    try: __import__(p.replace('-','_').lower()); print(f'  {p}: OK')
    except ImportError: print(f'  {p}: MISSING — run: pip install {p}')
"

echo "=== STEP 4: Login Test ===" && python3 -c "
try:
    from core.shoonya_client import login
    result = login()
    print(f'  Login: {\"OK\" if result else \"FAILED\"}')
    if not result:
        print('  Check: TOTP_KEY is permanent seed (not 6-digit code)')
        print('  Check: Password is correct (case sensitive)')
except Exception as e:
    print(f'  Login ERROR: {type(e).__name__}: {e}')
" 2>&1 | grep -v "token\|secret\|password"
```

## Common Fixes Quick Reference
| Symptom | Fix |
|---------|-----|
| `{}` empty data | Check market hours first |
| Login FAILED | TOTP_KEY is base32 seed key, not 6-digit code |
| ImportError NorenRestApiPy | `pip install NorenRestApiPy` |
| Missing credentials fields | Copy template and fill all fields |
| `iv` column missing | Normal for deep ITM/OTM — dashboard handles it |
