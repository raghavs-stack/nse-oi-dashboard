# /tune-signal — Tune Signal Sensitivity

Adjusts PCR thresholds and score parameters based on current performance.

## Usage
```
/tune-signal aggressive    # More signals, lower quality threshold
/tune-signal conservative  # Fewer signals, higher quality threshold
/tune-signal status        # Show current settings
```

## What it shows / changes

### Status
```bash
python3 -c "
from config import PCR_THRESHOLDS, MIN_SIGNAL_SCORE, MAX_TRADES_PER_DAY, MIN_TRADE_GAP_MINS
print('=== CURRENT SIGNAL SETTINGS ===')
print(f'  MIN_SIGNAL_SCORE:   {MIN_SIGNAL_SCORE}  (trade taken if score >= this)')
print(f'  MAX_TRADES_PER_DAY: {MAX_TRADES_PER_DAY}')
print(f'  MIN_TRADE_GAP_MINS: {MIN_TRADE_GAP_MINS} minutes')
print()
print('PCR Thresholds (contrarian):')
for k,v in PCR_THRESHOLDS.items():
    print(f'  {k:<12}: {v}')
print()
print('Interpretation:')
print(f'  PCR < {PCR_THRESHOLDS[\"STRONG_BUY\"]} → STRONG BUY (very bullish)')
print(f'  PCR < {PCR_THRESHOLDS[\"BUY\"]}       → BUY')
print(f'  PCR > {PCR_THRESHOLDS[\"SELL\"]}      → SELL')
print(f'  PCR > {PCR_THRESHOLDS[\"STRONG_SELL\"]} → STRONG SELL')
"
```

### Aggressive preset (more signals)
Changes in `config.py`:
```python
MIN_SIGNAL_SCORE = 45        # was 55
MIN_TRADE_GAP_MINS = 10      # was 15
PCR_THRESHOLDS = {
    "STRONG_BUY":  0.65,     # was 0.60
    "BUY":         0.85,     # was 0.80
    "SELL":        1.15,     # was 1.20
    "STRONG_SELL": 1.40,     # was 1.50
}
```

### Conservative preset (fewer, higher-quality signals)
Changes in `config.py`:
```python
MIN_SIGNAL_SCORE = 65        # was 55
MIN_TRADE_GAP_MINS = 30      # was 15
PCR_THRESHOLDS = {
    "STRONG_BUY":  0.55,     # was 0.60
    "BUY":         0.75,     # was 0.80
    "SELL":        1.25,     # was 1.20
    "STRONG_SELL": 1.60,     # was 1.50
}
```

## Instructions for Claude
When user runs `/tune-signal`:
1. Show current values with status command above
2. Ask which preset or ask for specific values
3. Edit `config.py` with exact changes
4. Show before/after comparison
5. Add a comment above each changed line: `# Tuned: <date> — <reason>`
6. Run `/check` after to validate
