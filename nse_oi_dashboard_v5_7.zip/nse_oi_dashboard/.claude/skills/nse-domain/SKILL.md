# NSE Options Domain Knowledge

## Options Market Structure

### Index Options (what this dashboard tracks)
- **NIFTY** — 50-stock index, lot size 50, weekly expiry (Thursday)
- **BANKNIFTY** — banking index, lot size 15, weekly expiry (Wednesday)
- **FINNIFTY** — financial index, lot size 40, Tuesday expiry

### Strike Intervals
| Symbol | Step | ATM calculation |
|--------|------|-----------------|
| NIFTY | 50 | `round(spot/50)*50` |
| BANKNIFTY | 100 | `round(spot/100)*100` |
| FINNIFTY | 50 | `round(spot/50)*50` |

### Market Hours
- Pre-open: 09:00–09:15 IST
- Regular session: 09:15–15:30 IST
- Post-close: 15:30–16:00 IST
- NSE API returns data only during regular session

---

## Open Interest (OI) Fundamentals

### What OI Tells Us
- OI = total outstanding contracts (not daily volume)
- Rising OI = new positions being built
- Falling OI = positions being closed/squared off

### OI + Price Interpretation
| Price | OI | Interpretation | Bias |
|-------|-----|---------------|------|
| ↑ | ↑ | Long Buildup | Bullish |
| ↓ | ↑ | Short Buildup | Bearish |
| ↑ | ↓ | Short Covering | Weak Bullish |
| ↓ | ↓ | Long Unwinding | Weak Bearish |

### Max CE OI = Resistance Wall
Writers (sellers) of calls at a strike have unlimited loss if spot crosses it.
→ They defend the level by selling more, creating resistance.
→ But if spot breaks above: call writers panic-cover → sharp move up (short squeeze)

### Max PE OI = Support Floor
Put writers defend their strike below spot.
→ Provides price support.
→ If broken: put writers panic-cover → sharp move down.

---

## Put-Call Ratio (PCR)

### Full Chain PCR
```
PCR = Total PE OI / Total CE OI
```

### Interpretation (CONTRARIAN)
| PCR | Market Condition | Signal |
|-----|-----------------|--------|
| < 0.6 | Extreme call writing, very bullish sentiment | STRONG BUY (oversold) |
| 0.6–0.8 | Moderate call writing | BUY |
| 0.8–1.2 | Balanced | NEUTRAL |
| 1.2–1.5 | Moderate put writing | SELL |
| > 1.5 | Extreme put writing, very bearish sentiment | STRONG SELL (overbought) |

**Why contrarian?** When everyone is writing calls (low PCR), market is crowded bullish → due for reversal. When everyone writes puts (high PCR), market is crowded bearish → due for reversal.

### Localized PCR (±8 strikes around ATM)
More reliable than full-chain PCR. Far OTM options distort the full reading. The dashboard uses local PCR as the primary signal.

---

## Implied Volatility (IV)

### ATM IV
- Implied volatility of the at-the-money option
- Best estimate of market's expected move size
- Low IV (< 12%) = calm market, range-bound expected
- High IV (> 25%) = panic buying, large moves expected

### IVR — IV Rank (0–100%)
```
IVR = (Current IV - 52w Low) / (52w High - 52w Low) × 100
```
- IVR 0–30%: IV is low relative to history → good for buying options
- IVR 70–100%: IV is high → good for selling options (high premium)

### IVP — IV Percentile
- What % of past year had IV lower than today's IV
- More robust than IVR for skewed distributions

### IV Skew
- Normal skew: Put IV > Call IV (puts more expensive = market pricing downside risk)
- Reverse skew: Call IV > Put IV (unusual, often in bull runs or short squeezes)
- Skew pct = (avg OTM Put IV - avg OTM Call IV)

---

## Advanced Analytics

### Gamma Exposure (GEX)
```
Net GEX = Σ(CE_OI × (Strike - Spot)) - Σ(PE_OI × (Spot - Strike))
```
- **Positive GEX**: MMs long gamma → buy dips + sell rallies → dampens volatility → range market
- **Negative GEX**: MMs short gamma → sell dips + buy rallies → amplifies moves → trending market
- **Gamma Flip**: Strike where cumulative GEX = 0. Below it = negative gamma territory

### Dealer Hedging Pressure
```
Call Pressure = Σ(CE_OI × (Spot - Strike))   # CEs where dealers are short
Put Pressure  = Σ(PE_OI × (Strike - Spot))   # PEs where dealers are short
Net = Call Pressure - Put Pressure
```
- Positive net → dealers buying futures (upside hedge) → bullish undercurrent
- Negative net → dealers selling futures (downside hedge) → bearish undercurrent

### Smart Money Detection
```
Smart Score = OI_Change × Volume × (1 / (IV + 1))
```
- Rationale: Smart money (institutions) build positions before IV expands
- High OI change + high volume + LOW IV = institutional entry
- Finds which strikes are seeing quiet, determined positioning

---

## Trading Signals Interpretation

### When to trade
- Score ≥ 55/100 (configurable)
- At least 3/5 votes aligned
- Between 09:45 and 14:45 IST (avoid first/last 30 minutes)
- VIX between 12–22 (too low = no premium, too high = too risky)

### When NOT to trade
- Last 45 minutes before expiry (theta crush + gamma risk)
- VIX sudden spike (IV crush risk if already long)
- Conflicting votes (2 BULLISH, 2 BEARISH, 1 NEUTRAL = skip)
- Score dropping on consecutive cycles (signal fading)
