# Python Patterns for Real-Time Trading Systems

## Core Patterns Used in This Project

### 1. Atomic Screen Refresh (Terminal)
```python
# Build entire output as list, then print atomically
# Prevents partial screen flicker
lines = []
lines.append(f"  SPOT: {spot:,.2f}")
lines.append(f"  PCR: {pcr:.3f}")

os.system("cls" if os.name == "nt" else "clear")
print("\n".join(lines))
```

### 2. Safe DataFrame Operations
```python
# Always guard empty
def calc_something(df: pd.DataFrame, spot: float) -> dict:
    if df.empty:
        return {"result": None, "signal": "N/A"}
    
    # Always copy before modifying
    d = df.copy()
    d["new_col"] = d["CE_OI"] * (spot - d["Strike"])
    
    # Guard missing columns
    if "CE_IV" not in d.columns:
        d["CE_IV"] = 0.0
    
    return {"result": float(d["new_col"].sum())}
```

### 3. Rolling Window State
```python
# In state.py — fixed-size rolling window
MAX_WINDOW = 252  # trading days in a year

class IVHistory:
    def __init__(self, max_size=MAX_WINDOW):
        self._data: list[float] = []
        self._max = max_size
    
    def update(self, value: float):
        self._data.append(value)
        if len(self._data) > self._max:
            self._data = self._data[-self._max:]
    
    def rank(self) -> float:
        if len(self._data) < 2:
            return 50.0
        lo, hi = min(self._data), max(self._data)
        if hi == lo:
            return 50.0
        return (self._data[-1] - lo) / (hi - lo) * 100
```

### 4. Safe API Call Pattern
```python
def fetch_with_retry(api_call, retries=3, delay=2) -> dict:
    """Wrap any API call with retry + safe default."""
    for attempt in range(retries):
        try:
            result = api_call()
            if result:
                return result
        except Exception as e:
            print(f"  Attempt {attempt+1}/{retries} failed: {type(e).__name__}")
            if attempt < retries - 1:
                time.sleep(delay)
    return {}
```

### 5. Namedtuple for Signals (immutable, type-safe)
```python
from typing import NamedTuple, Optional

class Signal(NamedTuple):
    time: str
    bias: str           # BULLISH | BEARISH | NEUTRAL
    spot: float
    pcr: float
    score: int          # 0-100
    taken: bool
    skip_reason: str
    atm_iv: float
    ivr: Optional[str]
    # ... etc
    
# Usage — immutable, hashable, printable
sig = Signal(time="10:30", bias="BULLISH", spot=24187.65, ...)
```

### 6. Config-First Constants
```python
# config.py — single source of truth
SYMBOL = "NIFTY"
LOT_SIZE = 50
REFRESH_RATE = 35
PCR_THRESHOLDS = {
    "STRONG_BUY": 0.60,
    "BUY": 0.80,
    "SELL": 1.20,
    "STRONG_SELL": 1.50,
}

# In any module:
from config import LOT_SIZE, PCR_THRESHOLDS
# NEVER: lot_size = 50  (magic number)
```

### 7. Atomic JSON State Write
```python
import json, tempfile, os

def write_state(state_data: dict, path: str = "dashboard_state.json"):
    """Write atomically to prevent Streamlit reading partial file."""
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(state_data, f)
        os.replace(tmp, path)  # atomic on all platforms
    except Exception as e:
        print(f"  State write error: {e}")
```

### 8. Tkinter Non-Blocking Refresh
```python
class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self._refresh()
    
    def _refresh(self):
        try:
            self._update_display()
        except Exception as e:
            print(f"  Display error: {e}")
        finally:
            # Schedule next refresh — NEVER use time.sleep() here
            self.after(REFRESH_RATE * 1000, self._refresh)
```

### 9. Pandas Vectorised Analytics (not iterrows)
```python
# Pattern: compute all strikes at once
def calc_max_pain(df: pd.DataFrame) -> float:
    strikes = df["Strike"].values
    ce_oi   = df["CE_OI"].values
    pe_oi   = df["PE_OI"].values
    
    # Vectorised loss computation for each strike
    pain = []
    for s in strikes:
        call_loss = ((strikes - s).clip(min=0) * ce_oi).sum()
        put_loss  = ((s - strikes).clip(min=0) * pe_oi).sum()
        pain.append(call_loss + put_loss)
    
    return float(strikes[pain.index(min(pain))])
```

### 10. Matplotlib Memory Safety
```python
def render_chart(data, path):
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.patch.set_facecolor("#0d1117")
    
    # ... build chart ...
    
    plt.tight_layout()
    plt.savefig(path, dpi=110, bbox_inches="tight")
    plt.close(fig)  # CRITICAL — always close, or memory leaks
```
