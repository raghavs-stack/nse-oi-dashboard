# Trading Analytics Formulas Reference

## Signal Scorer (9 factors, 0–100 pts)

```python
def score_signal(bias, votes, pcr, net_score, spot, max_pain,
                 vix_str, roc_alerts, tech_signal="NEUTRAL",
                 dealer_vote="NEUTRAL") -> tuple[int, dict, bool]:
    pts = {}
    
    # Factor 1: Unanimity (20 pts)
    all_votes = votes + [dealer_vote]
    unanimous = len(set(all_votes)) == 1
    pts["unanimity"] = (20 if unanimous else
                        10 if all_votes.count(bias) >= 4 else
                         5 if all_votes.count(bias) >= 3 else 0)
    
    # Factor 2: PCR extremity (15 pts) — how far from 1.0
    pts["pcr"] = min(15, int(abs(pcr - 1.0) * 38))
    
    # Factor 3: Net OI score magnitude (15 pts)
    pts["oi_score"] = min(15, int(abs(net_score) / 300_000 * 15))
    
    # Factor 4: Max pain alignment (10 pts)
    pain_dist = abs(spot - max_pain)
    moving_toward = ((bias == "BULLISH" and spot < max_pain) or
                     (bias == "BEARISH" and spot > max_pain))
    pts["max_pain"] = min(10, int(pain_dist / 50) * 2) if moving_toward else 0
    
    # Factor 5: VIX zone (10 pts)
    try:
        vix = float(vix_str)
        pts["vix"] = (10 if 12 <= vix <= 18 else
                       6 if 18 < vix <= 22  else
                       2 if vix > 22         else 4)
    except: pts["vix"] = 5
    
    # Factor 6: Time of day (10 pts)
    from core.market_hours import now_ist
    n = now_ist(); t = n.hour * 60 + n.minute
    pts["time"] = (0  if t < 9*60+30 or t > 14*60+45 else
                   10 if t <= 10*60+30                 else
                    8 if t <= 13*60                    else 5)
    
    # Factor 7: RoC confirmation (5 pts)
    roc = 0
    for alert in roc_alerts:
        if bias == "BULLISH" and "CALL" in alert: roc = 5; break
        if bias == "BEARISH" and "PUT"  in alert: roc = 5; break
    pts["roc"] = roc
    
    # Factor 8: RSI+VWAP (10 pts)
    pts["rsi_vwap"] = (10 if tech_signal == bias else
                        4 if tech_signal == "NEUTRAL" else 0)
    
    # Factor 9: Dealer hedge (5 pts)
    pts["dealer"] = (5 if dealer_vote == bias else
                     2 if dealer_vote == "NEUTRAL" else 0)
    
    return min(100, sum(pts.values())), pts, unanimous
```

---

## GEX Formula
```
call_gex_i = CE_OI_i × (Strike_i - Spot)
put_gex_i  = PE_OI_i × (Spot - Strike_i)
net_gex    = Σ call_gex - Σ put_gex

Gamma flip: strike where cumulative sorted net_gex ≈ 0
```

---

## Smart Money Score
```
smart_call_i = CE_Chg_i × CE_Vol_i × (1 / (CE_IV_i + 1))
smart_put_i  = PE_Chg_i × PE_Vol_i × (1 / (PE_IV_i + 1))

Top 3 strikes by each = institutional positioning
```

---

## Dealer Hedging
```
call_pressure_i = CE_OI_i × (Spot - Strike_i)   # CE_OI sold by dealers
put_pressure_i  = PE_OI_i × (Strike_i - Spot)   # PE_OI sold by dealers
net             = Σ call_pressure - Σ put_pressure

> 0: dealers net long futures (upside hedge) → BULLISH
< 0: dealers net short futures (downside hedge) → BEARISH
```

---

## OI Momentum (Build Rate)
```
call_mom_i = CE_Chg_i / (CE_OI_i + 1)
put_mom_i  = PE_Chg_i / (PE_OI_i + 1)

Focuses on ±300 pts from ATM
High momentum = aggressive new positioning regardless of absolute OI size
```

---

## IV Rank (IVR)
```
IVR = (Current_IV - Min_IV_252d) / (Max_IV_252d - Min_IV_252d) × 100
```

## IV Percentile (IVP)
```
IVP = count(days where historical_IV < current_IV) / 252 × 100
```

## ATM IV Skew
```
otm_put_iv  = mean(PE_IV for Strike < ATM - step)
otm_call_iv = mean(CE_IV for Strike > ATM + step)
skew_pct    = otm_put_iv - otm_call_iv

> 0: Put skew (bearish hedge, normal)
< 0: Call skew (bull run, unusual)
```

---

## Weighted OI Score (Bias Vote)
```python
# Weights favour near-ATM strikes
def calc_weighted_net_score(df, spot):
    d = df.copy()
    d["weight"] = 1 / (abs(d["Strike"] - spot) / 50 + 1)
    d["net"]    = d["CE_Chg"] - d["PE_Chg"]
    return (d["net"] * d["weight"]).sum()

# Positive → CE dominated → BEARISH (calls being written = resistance)
# Negative → PE dominated → BULLISH (puts being written = support)
```

---

## RSI (Wilder's Smoothed)
```python
def calc_rsi(prices: list, period=14) -> float:
    if len(prices) < period + 1: return None
    deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
    gains  = [max(d, 0) for d in deltas]
    losses = [max(-d, 0) for d in deltas]
    
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period-1) + gains[i]) / period
        avg_loss = (avg_loss * (period-1) + losses[i]) / period
    
    if avg_loss == 0: return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))
```
